-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `customerdb`;
CREATE TABLE `customerdb` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Number` int(11) NOT NULL,
  `Location` varchar(60) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `customerdb` (`ID`, `Name`, `Email`, `Number`, `Location`) VALUES
(3,	'Abiodun Adetona',	'adetonaabiodun12@gma',	2147483647,	'Ibadan.');

-- 2017-01-05 16:04:30
